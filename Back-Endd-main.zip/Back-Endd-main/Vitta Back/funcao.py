import hashlib
import re

def criptografar_senha(senha):

    return hashlib.sha256(senha.encode()).hexdigest()


def verificar_senha(senha, hash):

    return criptografar_senha(senha) == hash


def senha_forte(senha):

    if len(senha) < 8:
        return False

    if not re.search("[A-Z]", senha):
        return False

    if not re.search("[0-8]", senha):
        return False



    return True