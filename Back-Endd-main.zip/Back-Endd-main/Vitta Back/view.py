from flask import request, jsonify
import jwt
import datetime
from functools import wraps


def init_app(app):
    def criptografar(senha):
        return senha + "_hash"

    def checar_senha(senha, hash_armazenado):
        return criptografar(senha) == hash_armazenado

    def gerar_token(user_id):
        payload = {
            'id_usuario': user_id,
            'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=10)
        }
        token = jwt.encode(payload, app.config['SECRET_KEY'], algorithm='HS256')
        if isinstance(token, bytes):
            token = token.decode('utf-8')
        return token

    def remover_bearer(token):

        return token.replace("Bearer ", "")

    def token_obrigatorio(f):

        @wraps(f)
        def decorated(*args, **kwargs):
            token = request.headers.get('Authorization')
            if not token:
                return jsonify({'erro': 'Token não fornecido'}), 401

            token = remover_bearer(token)

            try:
                jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
            except jwt.ExpiredSignatureError:
                return jsonify({'erro': 'Token expirado'}), 401
            except jwt.InvalidTokenError:
                return jsonify({'erro': 'Token inválido'}), 401

            con = app.conectar()
            cur = con.cursor()
            try:
                cur.execute("""''
                            SELECT 1
                            FROM tokens
                            WHERE token = ?
                              AND expira_em > CURRENT_TIMESTAMP
                            """, (token,))
                if not cur.fetchone():
                    return jsonify({'erro': 'Token inválido no banco'}), 401
            finally:
                cur.close()
                con.close()

            return f(*args, **kwargs)

        return decorated


    @app.route('/usuario', methods=['POST'])
    def cadastrar_usuario():
        data = request.get_json()
        nome = data.get("nome")
        email = data.get("email")
        cpf = data.get("cpf")
        senha = data.get("senha")

        if not nome or not email or not cpf or not senha:
            return jsonify({"erro": "Preencha todos os campos"}), 400

        senha_hash = criptografar(senha)

        con = app.conectar()
        cur = con.cursor()
        try:
            cur.execute("""
                        INSERT INTO usuario (id, nome, email, cpf, senha_hash)
                        VALUES (GEN_ID(GEN_USUARIO_ID, 1), ?, ?, ?, ?) RETURNING id
                        """, (nome, email, cpf, senha_hash))

            user_id = cur.fetchone()[0]
            con.commit()

            return jsonify({
                "mensagem": "Usuário cadastrado com sucesso",
                "id": user_id
            }), 201

        except Exception as e:
            con.rollback()
            return jsonify({"erro": str(e)}), 500
        finally:
            cur.close()
            con.close()

    @app.route('/confirmar/<int:id>', methods=['GET'])
    def confirmar(id):
        """Confirma o email do usuário"""
        con = app.conectar()
        cur = con.cursor()
        try:
            cur.execute("""
                        UPDATE usuario
                        SET email_confirmado = TRUE
                        WHERE id = ?
                        """, (id,))
            con.commit()

            if cur.rowcount == 0:
                return jsonify({'erro': 'Usuário não encontrado'}), 404

            return jsonify({'mensagem': 'Email confirmado com sucesso'}), 200

        except Exception as e:
            con.rollback()
            return jsonify({'erro': str(e)}), 500
        finally:
            cur.close()
            con.close()

    @app.route('/login', methods=['POST'])
    def login():
        con = app.conectar()
        cur = con.cursor()
        try:
            dados = request.json
            email = dados.get('email')
            senha = dados.get('senha')

            if not email or not senha:
                return jsonify({'erro': 'Informe email e senha'}), 400

            cur.execute("""
                        SELECT id, senha_hash, tentativas_login, bloqueado, email_confirmado
                        FROM usuario
                        WHERE email = ?
                        """, (email,))
            user = cur.fetchone()

            if not user:
                return jsonify({'erro': 'Usuário não encontrado'}), 404

            if user[3]:  # bloqueado
                return jsonify({'erro': 'Usuário bloqueado'}), 403

            if not user[4]:
                return jsonify({'erro': 'Confirme seu email antes de fazer login'}), 403

            if not checar_senha(senha, user[1]):

                novas_tentativas = user[2] + 1
                cur.execute("""
                            UPDATE usuario
                            SET tentativas_login = ?
                            WHERE id = ?
                            """, (novas_tentativas, user[0]))

                if novas_tentativas >= 3:
                    cur.execute("""
                                UPDATE usuario
                                SET bloqueado = TRUE
                                WHERE id = ?
                                """, (user[0],))

                con.commit()
                return jsonify({'erro': 'Senha incorreta'}), 401

            cur.execute("""
                        UPDATE usuario
                        SET tentativas_login = 0
                        WHERE id = ?
                        """, (user[0],))

            token = gerar_token(user[0])
            expira = datetime.datetime.utcnow() + datetime.timedelta(minutes=10)

            cur.execute("""
                        INSERT INTO tokens (usuario_id, token, expira_em)
                        VALUES (?, ?, ?)
                        """, (user[0], token, expira))

            con.commit()

            return jsonify({
                'token': token,
                'mensagem': 'Login realizado com sucesso'
            }), 200

        except Exception as e:
            con.rollback()
            return jsonify({'erro': str(e)}), 500
        finally:
            cur.close()
            con.close()


    @app.route('/usuario', methods=['GET'])
    @token_obrigatorio
    def listar_usuario():
        con = app.conectar()
        cur = con.cursor()
        try:
            cur.execute('SELECT id, nome, email, bloqueado FROM usuario ORDER BY id')
            dados = cur.fetchall()
            lista = []
            for u in dados:
                lista.append({
                    'id': u[0],
                    'nome': u[1],
                    'email': u[2],
                    'bloqueado': bool(u[3])
                })
            return jsonify(lista), 200
        except Exception as e:
            return jsonify({'erro': str(e)}), 500
        finally:
            cur.close()
            con.close()

    @app.route('/editar_usuario/<int:id>', methods=['PUT'])
    @token_obrigatorio
    def editar_usuario(id):
        con = app.conectar()
        cur = con.cursor()
        try:
            dados = request.json
            nome = dados.get('nome')
            email = dados.get('email')

            if not nome and not email:
                return jsonify({'erro': 'Nenhum dado para atualizar'}), 400

            cur.execute('SELECT 1 FROM usuario WHERE id = ?', (id,))
            if not cur.fetchone():
                return jsonify({'erro': 'Usuário não encontrado'}), 404

            if email:
                cur.execute('SELECT 1 FROM usuario WHERE email = ? AND id <> ?', (email, id))
                if cur.fetchone():
                    return jsonify({'erro': 'Email já está em uso por outro usuário'}), 400

            updates = []
            params = []
            if nome:
                updates.append("nome = ?")
                params.append(nome)
            if email:
                updates.append("email = ?")
                params.append(email)
            params.append(id)

            query = f"UPDATE usuario SET {', '.join(updates)} WHERE id = ?"
            cur.execute(query, params)
            con.commit()

            return jsonify({'mensagem': 'Usuário atualizado com sucesso'}), 200

        except Exception as e:
            con.rollback()
            return jsonify({'erro': str(e)}), 500
        finally:
            cur.close()
            con.close()

    @app.route('/deletar_usuario/<int:id>', methods=['DELETE'])
    @token_obrigatorio
    def deletar_usuario(id):
        con = app.conectar()
        cur = con.cursor()
        try:
            cur.execute('SELECT 1 FROM usuario WHERE id = ?', (id,))
            if not cur.fetchone():
                return jsonify({'erro': 'Usuário não encontrado'}), 404

            cur.execute('DELETE FROM tokens WHERE usuario_id = ?', (id,))
            cur.execute('DELETE FROM recuperacao_senha WHERE usuario_id = ?', (id,))

            cur.execute('DELETE FROM usuario WHERE id = ?', (id,))
            con.commit()

            return jsonify({'mensagem': 'Usuário deletado com sucesso'}), 200

        except Exception as e:
            con.rollback()
            return jsonify({'erro': str(e)}), 500
        finally:
            cur.close()
            con.close()

    @app.route('/recuperar', methods=['POST'])
    def recuperar():
        con = app.conectar()
        cur = con.cursor()
        try:
            dados = request.json
            email = dados.get('email')

            if not email:
                return jsonify({'erro': 'Email é obrigatório'}), 400

            cur.execute("SELECT id FROM usuario WHERE email = ?", (email,))
            user = cur.fetchone()

            if not user:
                return jsonify({'erro': 'Usuário não encontrado'}), 404

            token = gerar_token(user[0])
            expira = datetime.datetime.utcnow() + datetime.timedelta(minutes=10)

            cur.execute("DELETE FROM recuperacao_senha WHERE usuario_id = ?", (user[0],))

            cur.execute("""
                        INSERT INTO recuperacao_senha (usuario_id, token, expira_em)
                        VALUES (?, ?, ?)
                        """, (user[0], token, expira))
            con.commit()

            return jsonify({
                'mensagem': 'Token de recuperação gerado com sucesso',
                'token': token
            }), 200

        except Exception as e:
            con.rollback()
            return jsonify({'erro': str(e)}), 500
        finally:
            cur.close()
            con.close()

    @app.route('/resetar_senha', methods=['POST'])
    def resetar_senha():
        con = app.conectar()
        cur = con.cursor()
        try:
            dados = request.json
            token = dados.get('token')
            nova_senha = dados.get('nova_senha')

            if not token or not nova_senha:
                return jsonify({'erro': 'Token e nova senha são obrigatórios'}), 400

            cur.execute("""
                        SELECT usuario_id
                        FROM recuperacao_senha
                        WHERE token = ?
                          AND expira_em > CURRENT_TIMESTAMP
                        """, (token,))
            resultado = cur.fetchone()

            if not resultado:
                return jsonify({'erro': 'Token inválido ou expirado'}), 400

            usuario_id = resultado[0]
            nova_senha_hash = criptografar(nova_senha)

            cur.execute("""
                        UPDATE usuario
                        SET senha_hash       = ?,
                            tentativas_login = 0,
                            bloqueado        = FALSE
                        WHERE id = ?
                        """, (nova_senha_hash, usuario_id))

            cur.execute("DELETE FROM recuperacao_senha WHERE token = ?", (token,))

            con.commit()

            return jsonify({'mensagem': 'Senha resetada com sucesso'}), 200

        except Exception as e:
            con.rollback()
            return jsonify({'erro': str(e)}), 500
        finally:
            cur.close()
            con.close()

    @app.route('/meus_dados', methods=['GET'])
    @token_obrigatorio
    def meus_dados():
        token = request.headers.get('Authorization')
        token = remover_bearer(token)

        try:
            payload = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
            user_id = payload['id_usuario']
        except:
            return jsonify({'erro': 'Token inválido'}), 401

        con = app.conectar()
        cur = con.cursor()
        try:
            cur.execute("""
                        SELECT id, nome, email, cpf, email_confirmado, bloqueado
                        FROM usuario
                        WHERE id = ?
                        """, (user_id,))
            user = cur.fetchone()

            if not user:
                return jsonify({'erro': 'Usuário não encontrado'}), 404

            return jsonify({
                'id': user[0],
                'nome': user[1],
                'email': user[2],
                'cpf': user[3],
                'email_confirmado': bool(user[4]),
                'bloqueado': bool(user[5])
            }), 200

        except Exception as e:
            return jsonify({'erro': str(e)}), 500
        finally:
            cur.close()
            con.close()

    @app.route('/logout', methods=['POST'])
    @token_obrigatorio
    def logout():
        token = request.headers.get('Authorization')
        token = remover_bearer(token)

        con = app.conectar()
        cur = con.cursor()
        try:
            cur.execute("DELETE FROM tokens WHERE token = ?", (token,))
            con.commit()
            return jsonify({'mensagem': 'Logout realizado com sucesso'}), 200
        except Exception as e:
            con.rollback()
            return jsonify({'erro': str(e)}), 500
        finally:
            cur.close()
            con.close()