class Config:

    SECRET_KEY = "chave_secreta"
    DB_HOST = "localhost"
    DB_PATH = r"C:\Users\Aluno\Downloads\Back-Endd-main\Back-Endd-main\Vitta Back\BANCO.FDB"
    DB_USER = "SYSDBA"
    DB_PASSWORD = "sysdba"
    UPLOAD_FOLDER = "uploads"

