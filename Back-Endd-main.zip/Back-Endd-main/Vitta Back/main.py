from flask import Flask
import fdb
import os


def create_app():
    app = Flask(__name__)


    app.config['SECRET_KEY'] = 'sua_chave_secreta'

    app.config['DB_HOST'] = 'localhost'
    app.config['DB_PATH'] = r"C:\Users\Aluno\Downloads\Back-Endd-main\Back-Endd-main\Vitta Back\BANCO.FDB"
    app.config['DB_USER'] = 'SYSDBA'
    app.config['DB_PASSWORD'] = 'sysdba'


    def conectar():
        try:
            con = fdb.connect(
                host=app.config['DB_HOST'],
                database=app.config['DB_PATH'],
                user=app.config['DB_USER'],
                password=app.config['DB_PASSWORD'],
                charset='UTF8'
            )
            return con

        except Exception as e:
            print("❌ Erro ao conectar no banco:", e)
            raise e

    app.conectar = conectar


    try:
        from view import init_app
        init_app(app)
    except Exception as e:
        print("❌ Erro ao carregar rotas:", e)


    @app.route('/')
    def home():
        return {"mensagem": "API rodando com sucesso 🚀"}

    return app




app = create_app()

if __name__ == '__main__':
    app.run(debug=True)