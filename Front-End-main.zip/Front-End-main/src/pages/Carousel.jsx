import { useState } from "react";
import styles from "../styles/Carousel.module.css";

function Carousel({ imagens }) {
    const [index, setIndex] = useState(0);

    const prev = () => {
        setIndex(index === 0 ? imagens.length - 1 : index - 1);
    };

    const next = () => {
        setIndex(index === imagens.length - 1 ? 0 : index + 1);
    };

    return (
        <div
            className={styles.carousel}
            style={{ backgroundImage: `url(${imagens[index]})` }}
        >
            <button className={`${styles.button} ${styles.prev}`} onClick={prev}>
                ◀
            </button>

            <button className={`${styles.button} ${styles.next}`} onClick={next}>
                ▶
            </button>
        </div>
    );
}

export default Carousel;