import Navbar from "../components/Navbar.jsx";
import styles from "../styles/Home.module.css";
import Carousel from "../pages/Carousel.jsx"; // use o Carousel que você já criou
import { useLocation } from "react-router-dom";
import Bannerimg from "../img/Banner.png";

function Home() {
    const location = useLocation();

    const emCartaz = [
        "https://picsum.photos/200/120?1",
        "https://picsum.photos/200/120?2",
        "https://picsum.photos/200/120?3",
        "https://picsum.photos/200/120?4",
    ];

    const emBreve = [
        "https://i.ytimg.com/vi/A0J_S8kWURI/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLBsBSqC_gSY_azUezUBERBfJDv44w",
        "https://picsum.photos/200/120?6",
        "https://picsum.photos/200/120?7",
    ];

    const maisAssistidos = [
        "https://picsum.photos/200/120?8",
        "https://picsum.photos/200/120?9",
        "https://picsum.photos/200/120?10",
    ];

    const recomendado = [
        "https://picsum.photos/200/120?11",
        "https://picsum.photos/200/120?12",
        "https://picsum.photos/200/120?13",
    ];

    return (
        <div className={styles.container}>
            <Navbar />

            {location.state?.mensagem && (
                <div className={styles.alert}>{location.state.mensagem}</div>
            )}

            {/* Hero/banner */}
            <section
                className={styles.hero}
                style={{ backgroundImage: `url(${Bannerimg})` }}
            >
                <div className={styles.imageOverlay}></div>
                <div className={styles.content}>
                    <span className={styles.badge}>Curadoria Exclusiva</span>
                    <p>
                        Catálogo de filmes exclusivos. Sempre haverá um destaque para sua semana.
                    </p>
                    <div className={styles.buttons}>
                        <a href="#catalogo" className={styles.primaryBtn}>
                            Explorar Catálogo
                        </a>
                        <a href="#promo" className={styles.secondaryBtn}>
                            Ver Promoções
                        </a>
                    </div>
                </div>
            </section>

            <section className={styles.section} id="catalogo">
                <h3>Em cartaz</h3>
                <Carousel imagens={emCartaz} />
            </section>

            <section className={styles.section}>
                <h3>Em breve</h3>
                <Carousel imagens={emBreve} />
            </section>

            <section className={styles.section}>
                <h3>Mais assistidos</h3>
                <Carousel imagens={maisAssistidos} />
            </section>

            <section className={styles.section}>
                <h3>Recomendado pra você</h3>
                <Carousel imagens={recomendado} />
            </section>

            <footer className={styles.footer}>
                <p>Copyright © 2024 Luminaflix</p>
            </footer>
        </div>
    );
}

export default Home;