// src/components/Footer.jsx
import styles from "../styles/Footer.module.css";

export default function Footer() {
    return (
        <footer className={styles.footer}>
            <div className={styles.left}>
                <h1>LuminaFlix</h1>
                <p>
                    Seu portal digital de catálogo, com uma seleção
                    <br/>
                    minuciosa de obras mais impactantes para o seu
                    <br/>
                    crescimento.
                </p>
                <div className={styles.socials}>
                    <a href="#" aria-label="Facebook" className={styles.socialLink}>
                        <span className="material-symbols-outlined">facebook</span>
                    </a>
                    <a href="#" aria-label="Instagram" className={styles.socialLink}>
                        <span className="material-symbols-outlined">instagram</span>
                    </a>
                    <a href="#" aria-label="Twitter" className={styles.socialLink}>
                        <span className="material-symbols-outlined">twitter</span>
                    </a>
                </div>
            </div>

            <div className={styles.linksSection}>
                <div>
                    <h3>Explorar</h3>
                    <a href="#">Lançamentos</a>
                    <a href="#">Mais vendidos</a>
                    <a href="#">E-books</a>
                </div>
                <div>
                    <h3>Suporte</h3>
                    <a href="#">Ajuda</a>
                    <a href="#">Fale Conosco</a>
                    <a href="#">Trocas</a>
                </div>
                <div>
                    <h3>Institucional</h3>
                    <a href="#">Sobre Nós</a>
                    <a href="#">Carreira</a>
                    <a href="#">Privacidade</a>
                </div>
            </div>
        </footer>
    );
}